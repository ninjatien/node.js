const express = require('express');
const router = express.Router();

// Display checkout page
router.get('/', (req, res) => {
  const cart = req.session.cart || [];

  const user = req.session.user || {
    name: 'Guest',
    email: 'guest@example.com'
  };

  res.render('checkout', { cart, user });
});

// Handle order placement
router.post('/place', (req, res) => {
  const cart = req.session.cart || [];
  const address = req.body.address;

  if (!address || address.trim() === '') {
    return res.status(400).send('Shipping address is required.');
  }

  // Simulate order placement and clear cart
  req.session.cart = [];

  res.send(`✅ Order placed successfully for ${cart.length} item(s) to: ${address}`);
});

module.exports = router;
