const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();

// Show register page
router.get('/register', (req, res) => {
  res.render('register');
});

// Register logic
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  const existing = req.app.locals.users.find(u => u.email === email);
  if (existing) return res.send('User already exists');

  const hashed = await bcrypt.hash(password, 10);
  const user = { name, email, password: hashed };
  req.app.locals.users.push(user);
  req.session.user = user;
  res.redirect('/');
});

// Show login page
router.get('/login', (req, res) => {
  res.render('login');
});

// Login logic
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = req.app.locals.users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.send('Invalid credentials');
  }
  req.session.user = user;
  res.redirect('/');
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
