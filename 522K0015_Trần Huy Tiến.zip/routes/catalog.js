const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

// Read product data path
const productsPath = path.join(__dirname, '..', 'data', 'products.json');

// Sort helper
function sortProducts(products, sortBy) {
  switch (sortBy) {
    case 'name-asc':
      return products.sort((a, b) => a.name.localeCompare(b.name));
    case 'name-desc':
      return products.sort((a, b) => b.name.localeCompare(a.name));
    case 'price-asc':
      return products.sort((a, b) => a.price - b.price);
    case 'price-desc':
      return products.sort((a, b) => b.price - a.price);
    default:
      return products; // no sorting
  }
}

// GET /catalog
router.get('/', (req, res) => {
  const sort = req.query.sort || '';

  fs.readFile(productsPath, 'utf8', (err, data) => {
    if (err) {
      console.error(' Error reading product data:', err);
      return res.status(500).send('Error loading product data');
    }

    let products = JSON.parse(data);
    products = sortProducts(products, sort);

    res.render('catalog', {
      products,
      sort,
      user: req.session.user // Pass user session so catalog.ejs can show login/register or user name
    });
  });
});

module.exports = router;
