const express = require('express');
const router = express.Router();
const fs = require('fs');

// In-memory user data (demo purpose)
const users = [
  {
    email: 'testadmin@gmail.com',
    password: 'testadmin',
    name: 'Admin',
    role: 'Admin',
    address: 'Default Address',
    username: 'testadmin'
  }
];

// ✅ Login page
router.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect(req.session.user.role === 'Admin' ? '/user/admin' : '/profile');
  }
  res.render('login', { error: null });
});

// ✅ Handle login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    req.session.user = user;
    return res.redirect(user.role === 'Admin' ? '/user/admin' : '/profile');
  }

  res.render('login', { error: 'Invalid credentials' });
});

// ✅ Register page
router.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/profile');
  res.render('register', { error: null });
});

// ✅ Handle register
router.post('/register', (req, res) => {
  const { name, email, password } = req.body;

  const emailPattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
  if (!emailPattern.test(email)) {
    return res.render('register', { error: 'Please enter a valid email address.' });
  }

  if (users.find(u => u.email === email)) {
    return res.render('register', { error: 'Email already registered.' });
  }

  const username = email.split('@')[0];
  users.push({ name, email, password, role: 'user', address: '', username });
  res.redirect('/login');
});

// ✅ Profile page
router.get('/profile', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  res.render('profile', { user: req.session.user });
});

// ✅ Handle address update
router.post('/profile', (req, res) => {
  if (!req.session.user) return res.redirect('/login');

  const newAddress = req.body.address;
  req.session.user.address = newAddress;

  res.redirect('/profile');
});

// ✅ Admin dashboard
router.get('/admin', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'Admin') {
    return res.status(403).send('Access denied: Admins only.');
  }
  res.render('admin', { user: req.session.user });
});

// ✅ Password recovery page
router.get('/recover', (req, res) => {
  res.render('recover', { message: null, error: null });
});

// ✅ Handle password recovery
router.post('/recover', (req, res) => {
  const { username } = req.body;
  const user = users.find(u => u.username === username);

  if (user) {
    return res.render('recover', {
      message: `Your password is: ${user.password}`, // ⚠️ For testing only
      error: null
    });
  }

  res.render('recover', {
    message: null,
    error: 'Username not found'
  });
});

module.exports = router;
