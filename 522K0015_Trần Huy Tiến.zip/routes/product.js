const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

// Load products safely using fs
const productsFilePath = path.join(__dirname, '../data/products.json');
let products = [];

try {
  const rawData = fs.readFileSync(productsFilePath, 'utf-8');
  products = JSON.parse(rawData);
} catch (err) {
  console.error('Error loading products.json:', err.message);
}

// Route: GET /product/:id
router.get('/:id', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).send('Product not found');
  }

  res.render('product', { product });
});

// Route: POST /product/:id/comment
router.post('/:id/comment', (req, res) => {
  const productId = parseInt(req.params.id);
  const product = products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).send('Product not found');
  }

  const { comment, rating } = req.body;

  // Push new comment
  if (!product.comments) {
    product.comments = [];
  }

  product.comments.push({
    username: 'Anonymous',
    text: comment,
    rating: parseInt(rating)
  });

  // Save changes back to products.json
  try {
    fs.writeFileSync(productsFilePath, JSON.stringify(products, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write to products.json:', err.message);
  }

  res.redirect(`/product/${productId}`);
});

module.exports = router;
