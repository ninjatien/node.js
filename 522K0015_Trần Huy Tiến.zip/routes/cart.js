const express = require('express');
const router = express.Router();

// Add product to cart
router.post('/add', (req, res) => {
  const { productId } = req.body;
  const products = req.app.locals.products;

  if (!products) {
    return res.status(500).send('Product list not available.');
  }

  const product = products.find(p => p.id === parseInt(productId));
  if (!product) {
    return res.status(404).send('Product not found.');
  }

  if (!req.session.cart) {
    req.session.cart = [];
  }

  req.session.cart.push(product);
  res.redirect('/cart');
});

// View cart
router.get('/', (req, res) => {
  const cart = req.session.cart || [];
  res.render('cart', { cart });
});

// Remove item from cart
router.post('/remove', (req, res) => {
  const { productId } = req.body;
  const cart = req.session.cart || [];

  // Filter out the item
  req.session.cart = cart.filter(item => item.id !== parseInt(productId));
  res.redirect('/cart');
});

module.exports = router;
