const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const bodyParser = require('body-parser');
const catalogRoutes = require('./routes/catalog');

// Load product data
let products = [];
try {
  products = JSON.parse(fs.readFileSync('./data/products.json', 'utf-8'));
} catch (error) {
  console.error('Error loading products data:', error);
}

// Set products globally for use in views
app.locals.products = products;

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Session management
app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: true
}));

// Routes
const productRoutes = require('./routes/product');
const cartRoutes = require('./routes/cart');
const checkoutRoutes = require('./routes/checkout');
const userRoutes = require('./routes/user');

app.use('/product', productRoutes);
app.use('/cart', cartRoutes);
app.use('/checkout', checkoutRoutes);
app.use('/catalog', catalogRoutes);
app.use('/', userRoutes);

// ✅ Home page (modified)
app.get('/', (req, res) => {
  console.log('✅ Home page accessed');
  res.render('home', { products, user: req.session.user || null });
});

// ✅ Admin Dashboard
app.get('/user/admin', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'Admin') {
    return res.status(403).send('Access denied');
  }
  res.render('admin', { user: req.session.user });
});

// ✅ Profile page
app.get('/profile', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  res.render('profile', { user: req.session.user });
});

// ✅ Login page
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/profile');
  res.render('login', { error: null });
});

// ✅ Register page
app.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/profile');
  res.render('register', { error: null });
});

// ✅ Logout
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/');
  });
});

// ✅ Catalog page
app.get('/catalog', (req, res) => {
  console.log('✅ Catalog page accessed');
  res.render('catalog', { products, user: req.session.user });
});

// ✅ Individual product page
app.get('/product/:id', (req, res) => {
  console.log(`✅ Product page accessed for ID: ${req.params.id}`);
  const product = products.find(p => p.id === req.params.id);
  if (!product) {
    console.warn(`❌ Product not found: ${req.params.id}`);
    return res.status(404).send('Product not found');
  }
  res.render('product', { product, user: req.session.user });
});

// ❌ 404 must be LAST
app.use((req, res, next) => {
  console.warn(`❌ 404 Page not found: ${req.originalUrl}`);
  res.status(404).send('Page not found');
});

// ✅ Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
